"""Session management: X3DH key agreement feeding the Double Ratchet.

:class:`SessionManager` owns a user's X3DH state and one Double Ratchet per
peer. It is used identically by the Android client (in production) and by the
backend's integration tests (to prove the server only ever sees ciphertext).

The associated data for every message is the deterministic string
``"<sender_id>|<recipient_id>"`` so both endpoints authenticate the same value
without extra coordination.
"""

from __future__ import annotations

import hashlib
from typing import Dict, Optional

from x3dh import Bundle

from .constants import (
    DOS_PROTECTION_THRESHOLD,
    MAX_SKIPPED_MESSAGE_KEYS,
    MESSAGE_CHAIN_CONSTANT,
)
from .envelope import Envelope
from .primitives import AesGcm, HkdfSha256, MSJDoubleRatchet, X25519Ratchet
from .x3dh_state import X3DHState


class CryptoError(Exception):
    """Base class for E2EE errors raised by this package."""


class NoSessionError(CryptoError):
    """Raised when a message cannot be handled because no session exists yet."""


class Session:
    """A one-to-one Double Ratchet session with a single peer."""

    def __init__(self, ratchet: MSJDoubleRatchet) -> None:
        self.ratchet = ratchet

    def export(self) -> dict:
        """Serialise the ratchet state (contains private key material)."""
        return self.ratchet.json

    @classmethod
    def load(cls, serialized: dict) -> "Session":
        ratchet = MSJDoubleRatchet.from_json(
            serialized,
            X25519Ratchet,
            HkdfSha256,
            HkdfSha256,
            MESSAGE_CHAIN_CONSTANT,
            DOS_PROTECTION_THRESHOLD,
            MAX_SKIPPED_MESSAGE_KEYS,
            AesGcm,
        )
        return cls(ratchet)


class SessionManager:
    """Owns X3DH state and per-peer Double Ratchet sessions for one user."""

    def __init__(self, own_id: str, state: Optional[X3DHState] = None) -> None:
        self.own_id = own_id
        self.state = state if state is not None else X3DHState.new()
        self._sessions: Dict[str, Session] = {}

    # ---- identity / bundle ------------------------------------------------

    @property
    def bundle(self) -> Bundle:
        return self.state.bundle

    def identity_public_key(self) -> bytes:
        return self.bundle.identity_key

    def has_session(self, peer_id: str) -> bool:
        return peer_id in self._sessions

    def _ad_out(self, peer_id: str) -> bytes:
        """Associated data for a message we send: ``sender|recipient``."""
        return f"{self.own_id}|{peer_id}".encode("utf-8")

    def _ad_in(self, peer_id: str) -> bytes:
        """Associated data for a message we receive: ``sender|recipient``.

        Same string as the sender computes, so both endpoints authenticate an
        identical value.
        """
        return f"{peer_id}|{self.own_id}".encode("utf-8")

    def safety_number(self, peer_id: str, peer_identity_key: bytes) -> str:
        """A 60-digit safety number both parties can compare out of band.

        Derived deterministically from both identity public keys, ordered so
        both sides compute the same value.
        """
        own = self.identity_public_key()
        peer = peer_identity_key
        if own > peer:
            own, peer = peer, own
        digest = hashlib.sha512(own + peer).digest()
        number = int.from_bytes(digest, "big")
        return str(number % 10**60).zfill(60)

    # ---- encryption -------------------------------------------------------

    async def encrypt(
        self,
        peer_id: str,
        plaintext: bytes,
        peer_bundle: Optional[Bundle] = None,
    ) -> Envelope:
        """Encrypt a message for ``peer_id``.

        If no session exists yet, ``peer_bundle`` (the recipient's published
        X3DH bundle) is required to establish one via X3DH.
        """
        ad = self._ad_out(peer_id)
        session = self._sessions.get(peer_id)

        if session is None:
            if peer_bundle is None:
                raise NoSessionError(f"No session with {peer_id!r}; a peer bundle is required to start one.")
            shared_secret, _x3dh_ad, x3dh_header = await self.state.get_shared_secret_active(
                peer_bundle,
                associated_data_appendix=ad,
                # A one-time pre key is used when available, exactly as in
                # Signal; if the recipient has exhausted theirs we fall back to
                # the signed pre key alone. The receiver detects which was used
                # from the header, so both sides stay in agreement.
                require_pre_key=bool(peer_bundle.pre_keys),
            )
            ratchet, message = await MSJDoubleRatchet.encrypt_initial_message(
                X25519Ratchet,
                HkdfSha256,
                HkdfSha256,
                MESSAGE_CHAIN_CONSTANT,
                DOS_PROTECTION_THRESHOLD,
                MAX_SKIPPED_MESSAGE_KEYS,
                AesGcm,
                shared_secret,
                peer_bundle.signed_pre_key,
                plaintext,
                ad,
            )
            self._sessions[peer_id] = Session(ratchet)
            return Envelope.from_ratchet(message, x3dh_header)

        message = await session.ratchet.encrypt_message(plaintext, ad)
        return Envelope.from_ratchet(message, None)

    # ---- decryption -------------------------------------------------------

    async def decrypt(self, peer_id: str, envelope: Envelope) -> bytes:
        """Decrypt an envelope from ``peer_id``."""
        ad = self._ad_in(peer_id)

        if envelope.x3dh is not None:
            # First message of a conversation: complete the X3DH agreement.
            shared_secret, _x3dh_ad, signed_pre_key = await self.state.get_shared_secret_passive(
                envelope.x3dh.to_header(),
                associated_data_appendix=ad,
                require_pre_key=envelope.x3dh.pre_key is not None,
            )
            ratchet, plaintext = await MSJDoubleRatchet.decrypt_initial_message(
                X25519Ratchet,
                HkdfSha256,
                HkdfSha256,
                MESSAGE_CHAIN_CONSTANT,
                DOS_PROTECTION_THRESHOLD,
                MAX_SKIPPED_MESSAGE_KEYS,
                AesGcm,
                shared_secret,
                signed_pre_key.priv,
                envelope.to_ratchet(),
                ad,
            )
            self._sessions[peer_id] = Session(ratchet)
            return plaintext

        session = self._sessions.get(peer_id)
        if session is None:
            raise NoSessionError(f"Received a follow-up message from {peer_id!r} without an established session.")
        return await session.ratchet.decrypt_message(envelope.to_ratchet(), ad)

    # ---- persistence ------------------------------------------------------

    def export_sessions(self) -> Dict[str, dict]:
        """Serialise all peer sessions (private key material)."""
        return {peer: session.export() for peer, session in self._sessions.items()}

    def load_sessions(self, data: Dict[str, dict]) -> None:
        self._sessions = {peer: Session.load(blob) for peer, blob in data.items()}


__all__ = ["Session", "SessionManager", "CryptoError", "NoSessionError"]
