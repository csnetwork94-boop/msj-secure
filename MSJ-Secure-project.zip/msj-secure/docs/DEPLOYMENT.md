# Deployment

## Local development

```bash
python -m pip install -r backend/requirements-dev.txt
cd backend
PYTHONPATH=.:../shared uvicorn app.main:app --reload
```

SQLite is used by default; no TLS is required in development.

## Production (recommended shape)

1. **PostgreSQL** as the database.
2. **uvicorn** (or gunicorn with uvicorn workers) behind a **TLS-terminating
   reverse proxy** (nginx or Caddy).
3. Secrets from the environment / a secret manager — never committed.

### With Docker Compose

```bash
export MSJ_JWT_SECRET="$(python -c 'import secrets;print(secrets.token_urlsafe(48))')"
export POSTGRES_PASSWORD="a-strong-db-password"
docker compose up --build -d
```

Then apply migrations inside the backend container:

```bash
docker compose exec backend alembic upgrade head
```

### Environment variables

See `.env.example`. In production set at minimum:

```
MSJ_ENVIRONMENT=production
MSJ_DATABASE_URL=postgresql+asyncpg://USER:PASS@HOST:5432/msj
MSJ_JWT_SECRET=<long random value>
MSJ_REQUIRE_TLS=true
```

With `MSJ_REQUIRE_TLS=true`, the app rejects requests that are not HTTPS
(honouring `X-Forwarded-Proto` from the proxy) and sends HSTS.

### Reverse proxy sketch (nginx)

```
server {
    listen 443 ssl http2;
    server_name chat.example.com;
    ssl_certificate     /etc/letsencrypt/live/chat.example.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/chat.example.com/privkey.pem;

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        # WebSocket upgrade
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_read_timeout 3600s;
    }
}
```

### Scaling notes

- The rate limiter is in-process. For multiple backend instances, back it with a
  shared store (e.g. Redis).
- WebSocket connections are held per instance; use sticky routing or a shared
  pub/sub (e.g. Redis) to fan out messages across instances.
- Schedule a retention purge job to delete messages past
  `MSJ_MESSAGE_RETENTION_DAYS`.

### Health check

`GET /healthz` returns `{"status":"ok"}`.
