#!/usr/bin/env bash
# Install the Android build toolchain and build a debug APK.
# Used by the GitHub Actions workflow (.github/workflows/android.yml) and
# runnable on any Debian/Ubuntu machine.
set -euo pipefail
here="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$here"

SUDO=""
if [ "$(id -u)" -ne 0 ] && command -v sudo >/dev/null 2>&1; then SUDO="sudo"; fi

$SUDO apt-get update
$SUDO apt-get install -y git zip unzip openjdk-17-jdk autoconf automake libtool \
  pkg-config zlib1g-dev libncurses5-dev libncursesw5-dev cmake libffi-dev libssl-dev

python -m pip install --upgrade pip
pip install buildozer cython

# Make the shared E2EE core available to the client build.
rm -rf client/msj_crypto
cp -r shared/msj_crypto client/msj_crypto

cd client
yes | buildozer -v android debug
echo "APK(s):"
ls -la bin/*.apk || true
