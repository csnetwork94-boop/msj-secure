"""REST and WebSocket transport to the MSJ Secure backend."""
from __future__ import annotations

import asyncio
import json
from typing import Any, AsyncIterator, Callable, Optional

import httpx

from .config import ClientConfig


class ApiError(Exception):
    def __init__(self, status_code: int, detail: str) -> None:
        super().__init__(f"HTTP {status_code}: {detail}")
        self.status_code = status_code
        self.detail = detail


class ApiClient:
    """Thin async REST client with automatic access-token refresh."""

    def __init__(
        self,
        config: ClientConfig,
        transport: Optional[httpx.AsyncBaseTransport] = None,
    ) -> None:
        self.config = config
        self._client = httpx.AsyncClient(
            base_url=config.base_url,
            timeout=config.request_timeout,
            transport=transport,
        )
        self.access_token: Optional[str] = None
        self.refresh_token: Optional[str] = None
        self.user_id: Optional[str] = None
        self.device_id: Optional[str] = None

    async def aclose(self) -> None:
        await self._client.aclose()

    # ---- helpers ----------------------------------------------------------

    def _auth_headers(self) -> dict:
        return {"Authorization": f"Bearer {self.access_token}"} if self.access_token else {}

    async def _request(self, method: str, url: str, *, retry_on_401: bool = True, **kwargs) -> httpx.Response:
        headers = kwargs.pop("headers", {})
        headers = {**self._auth_headers(), **headers}
        resp = await self._client.request(method, url, headers=headers, **kwargs)
        if resp.status_code == 401 and retry_on_401 and self.refresh_token:
            if await self._try_refresh():
                return await self._request(method, url, retry_on_401=False, **kwargs)
        if resp.status_code >= 400:
            detail = "error"
            try:
                detail = resp.json().get("detail", detail)
            except Exception:
                detail = resp.text or detail
            raise ApiError(resp.status_code, str(detail))
        return resp

    async def _try_refresh(self) -> bool:
        try:
            resp = await self._client.post("/api/v1/auth/refresh", json={"refresh_token": self.refresh_token})
        except httpx.HTTPError:
            return False
        if resp.status_code != 200:
            return False
        self._apply_tokens(resp.json())
        return True

    def _apply_tokens(self, data: dict) -> None:
        self.access_token = data["access_token"]
        self.refresh_token = data["refresh_token"]
        self.user_id = data.get("user_id", self.user_id)
        self.device_id = data.get("device_id", self.device_id)

    # ---- auth -------------------------------------------------------------

    async def register(self, username: str, password: str, device_name: str = "android") -> dict:
        resp = await self._client.post(
            "/api/v1/auth/register",
            json={"username": username, "password": password, "device_name": device_name, "platform": "android"},
        )
        if resp.status_code >= 400:
            raise ApiError(resp.status_code, resp.json().get("detail", "registration failed"))
        self._apply_tokens(resp.json())
        return resp.json()

    async def login(self, username: str, password: str, device_name: str = "android") -> dict:
        resp = await self._client.post(
            "/api/v1/auth/login",
            json={"username": username, "password": password, "device_name": device_name, "platform": "android"},
        )
        if resp.status_code >= 400:
            raise ApiError(resp.status_code, resp.json().get("detail", "login failed"))
        self._apply_tokens(resp.json())
        return resp.json()

    async def logout(self) -> None:
        await self._request("POST", "/api/v1/auth/logout")

    # ---- keys -------------------------------------------------------------

    async def publish_bundle(self, bundle_wire: dict) -> None:
        await self._request("PUT", "/api/v1/keys/bundle", json=bundle_wire)

    async def refill_prekeys(self, pre_keys: list[str]) -> None:
        await self._request("POST", "/api/v1/keys/prekeys", json={"pre_keys": pre_keys})

    async def key_status(self) -> dict:
        return (await self._request("GET", "/api/v1/keys/status")).json()

    async def fetch_bundle(self, username: str) -> dict:
        return (await self._request("GET", f"/api/v1/keys/bundle/{username}")).json()

    # ---- users ------------------------------------------------------------

    async def search_users(self, q: str, limit: int = 20, offset: int = 0) -> dict:
        return (
            await self._request("GET", "/api/v1/users/search", params={"q": q, "limit": limit, "offset": offset})
        ).json()

    # ---- messages ---------------------------------------------------------

    async def send_message(self, client_msg_id: str, recipient: str, envelope: dict) -> dict:
        resp = await self._request(
            "POST",
            "/api/v1/messages",
            json={"client_msg_id": client_msg_id, "recipient": recipient, "envelope": envelope},
        )
        return resp.json()

    async def history(self, peer: str, limit: int = 50, cursor: Optional[str] = None) -> dict:
        params: dict[str, Any] = {"peer": peer, "limit": limit}
        if cursor:
            params["cursor"] = cursor
        return (await self._request("GET", "/api/v1/messages", params=params)).json()

    async def send_receipt(self, message_id: str, status: str) -> None:
        await self._request("POST", f"/api/v1/messages/{message_id}/receipt", json={"status": status})

    async def list_devices(self) -> list[dict]:
        return (await self._request("GET", "/api/v1/devices")).json()

    async def revoke_device(self, device_id: str) -> None:
        await self._request("DELETE", f"/api/v1/devices/{device_id}")


class RealtimeClient:
    """Reconnecting WebSocket client for live ciphertext delivery."""

    def __init__(self, config: ClientConfig, api: ApiClient) -> None:
        self.config = config
        self.api = api
        self._ws = None
        self._task: Optional[asyncio.Task] = None
        self._running = False

    async def _connect(self):
        import websockets  # imported lazily so the REST-only path needs no WS dep

        return await websockets.connect(f"{self.config.ws_url}?token={self.api.access_token}")

    async def run(self, on_event: Callable[[dict], Any]) -> None:
        """Connect and deliver parsed frames to ``on_event`` with backoff."""
        self._running = True
        backoff = 1.0
        while self._running:
            try:
                self._ws = await self._connect()
                backoff = 1.0
                async for raw in self._ws:
                    await _maybe_await(on_event(json.loads(raw)))
            except Exception:
                if not self._running:
                    break
                await asyncio.sleep(backoff)
                backoff = min(backoff * 2, 30.0)
            finally:
                if self._ws is not None:
                    try:
                        await self._ws.close()
                    except Exception:
                        pass
                    self._ws = None

    async def send(self, payload: dict) -> None:
        if self._ws is not None:
            await self._ws.send(json.dumps(payload))

    async def stop(self) -> None:
        self._running = False
        if self._ws is not None:
            try:
                await self._ws.close()
            except Exception:
                pass


async def _maybe_await(value: Any) -> None:
    if asyncio.iscoroutine(value):
        await value
