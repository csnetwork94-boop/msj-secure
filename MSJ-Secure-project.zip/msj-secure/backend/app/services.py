"""Business logic shared between the REST routes and the WebSocket relay."""

from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from typing import Optional, Tuple

from fastapi import HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from .config import Settings
from .models import AuditLog, Device, Message, RefreshToken, User
from .security import generate_refresh_token, hash_refresh_token


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


async def audit(session: AsyncSession, event: str, user_id: Optional[str] = None, detail: Optional[str] = None) -> None:
    session.add(AuditLog(event=event, user_id=user_id, detail=detail))


async def create_device_with_tokens(
    session: AsyncSession,
    settings: Settings,
    user: User,
    name: str,
    platform: str,
) -> Tuple[Device, str]:
    """Register a new device and issue a refresh token for it.

    Returns the device and the *raw* refresh token (only its hash is stored).
    """
    device = Device(user_id=user.id, name=name[:64], platform=platform[:32])
    session.add(device)
    await session.flush()

    raw = generate_refresh_token()
    session.add(
        RefreshToken(
            user_id=user.id,
            device_id=device.id,
            token_hash=hash_refresh_token(raw),
            expires_at=_utcnow() + timedelta(days=settings.refresh_token_ttl_days),
        )
    )
    await session.flush()
    return device, raw


async def rotate_refresh_token(
    session: AsyncSession,
    settings: Settings,
    raw_token: str,
) -> Tuple[User, Device, str]:
    """Validate and rotate a refresh token, returning (user, device, new_raw).

    Reuse of an already-rotated token revokes every token for that device.
    """
    token_hash = hash_refresh_token(raw_token)
    row = (
        await session.execute(select(RefreshToken).where(RefreshToken.token_hash == token_hash))
    ).scalar_one_or_none()

    if row is None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="invalid refresh token")

    if row.revoked_at is not None:
        # Token reuse: revoke the whole device's tokens.
        rows = (
            (await session.execute(select(RefreshToken).where(RefreshToken.device_id == row.device_id))).scalars().all()
        )
        for r in rows:
            if r.revoked_at is None:
                r.revoked_at = _utcnow()
        await audit(session, "refresh_reuse_detected", row.user_id)
        await session.commit()
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="refresh token reused")

    expires_at = row.expires_at
    if expires_at.tzinfo is None:
        expires_at = expires_at.replace(tzinfo=timezone.utc)
    if expires_at < _utcnow():
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="refresh token expired")

    device = await session.get(Device, row.device_id)
    if device is None or device.revoked_at is not None:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="device revoked")

    user = await session.get(User, row.user_id)
    if user is None or not user.is_active:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="invalid user")

    # Rotate: revoke old, issue new.
    row.revoked_at = _utcnow()
    raw = generate_refresh_token()
    session.add(
        RefreshToken(
            user_id=user.id,
            device_id=device.id,
            token_hash=hash_refresh_token(raw),
            expires_at=_utcnow() + timedelta(days=settings.refresh_token_ttl_days),
        )
    )
    await session.flush()
    return user, device, raw


async def get_user_by_username(session: AsyncSession, username: str) -> Optional[User]:
    return (
        await session.execute(select(User).where(User.username_lower == username.strip().lower()))
    ).scalar_one_or_none()


def _validate_envelope(settings: Settings, envelope: dict) -> str:
    try:
        blob = json.dumps(envelope, separators=(",", ":"))
    except (TypeError, ValueError) as exc:
        raise HTTPException(status_code=422, detail="envelope is not JSON-serialisable") from exc
    if len(blob.encode("utf-8")) > settings.max_message_envelope_bytes:
        raise HTTPException(status_code=413, detail="envelope too large")
    # Structural sanity only; the server never decrypts.
    for required in ("ratchet_pub", "pn", "n", "ciphertext"):
        if required not in envelope:
            raise HTTPException(status_code=422, detail=f"envelope missing field: {required}")
    return blob


async def send_message_core(
    session: AsyncSession,
    settings: Settings,
    manager,
    sender: User,
    recipient_username: str,
    client_msg_id: str,
    envelope: dict,
) -> dict:
    """Store a ciphertext message and attempt real-time delivery.

    Idempotent on (sender, client_msg_id): a resend returns the existing record.
    """
    blob = _validate_envelope(settings, envelope)

    recipient = await get_user_by_username(session, recipient_username)
    if recipient is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="recipient not found")

    # Duplicate-message protection (client retries).
    existing = (
        await session.execute(
            select(Message).where(Message.sender_id == sender.id, Message.client_msg_id == client_msg_id)
        )
    ).scalar_one_or_none()
    if existing is not None:
        return {
            "id": existing.id,
            "client_msg_id": existing.client_msg_id,
            "status": "delivered" if existing.delivered_at else "stored",
        }

    message = Message(
        client_msg_id=client_msg_id,
        sender_id=sender.id,
        recipient_id=recipient.id,
        envelope=blob,
        size_bytes=len(blob.encode("utf-8")),
        expires_at=_utcnow() + timedelta(days=settings.message_retention_days),
    )
    session.add(message)
    await session.flush()

    # Try real-time delivery.
    payload = {
        "type": "message",
        "id": message.id,
        "client_msg_id": message.client_msg_id,
        "sender": sender.username,
        "envelope": envelope,
        "created_at": message.created_at.isoformat(),
    }
    delivered = await manager.send_to_user(recipient.id, payload)
    if delivered:
        message.delivered_at = _utcnow()

    await session.commit()
    return {
        "id": message.id,
        "client_msg_id": message.client_msg_id,
        "status": "delivered" if delivered else "stored",
    }
