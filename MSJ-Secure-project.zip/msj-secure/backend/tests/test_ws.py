"""WebSocket relay tests (real-time delivery, offline queue flush, auth)."""

from __future__ import annotations

import asyncio

from app.main import app
from msj_crypto import Envelope, SessionManager, bundle_from_bundle_response, bundle_to_wire
from starlette.testclient import TestClient

PASSWORD = "supersecret123"


def _register(tc: TestClient, username: str) -> dict:
    r = tc.post(
        "/api/v1/auth/register",
        json={"username": username, "password": PASSWORD, "device_name": "d", "platform": "test"},
    )
    assert r.status_code == 201, r.text
    return r.json()


def _publish(tc: TestClient, headers: dict, manager: SessionManager) -> None:
    r = tc.put("/api/v1/keys/bundle", json=bundle_to_wire(manager.bundle), headers=headers)
    assert r.status_code == 204, r.text


def test_ws_realtime_and_offline_flush():
    with TestClient(app) as tc:
        a = _register(tc, "alice")
        b = _register(tc, "bob")
        ah = {"Authorization": f"Bearer {a['access_token']}"}
        bh = {"Authorization": f"Bearer {b['access_token']}"}

        am, bm = SessionManager("alice"), SessionManager("bob")
        _publish(tc, ah, am)
        _publish(tc, bh, bm)

        # --- offline delivery: Bob is not connected yet ---
        bundle = bundle_from_bundle_response(tc.get("/api/v1/keys/bundle/bob", headers=ah).json())
        env1 = asyncio.run(am.encrypt("bob", b"offline hello", peer_bundle=bundle))
        r = tc.post(
            "/api/v1/messages",
            json={"client_msg_id": "o1", "recipient": "bob", "envelope": env1.to_dict()},
            headers=ah,
        )
        assert r.json()["status"] == "stored"

        with tc.websocket_connect(f"/api/v1/ws?token={b['access_token']}") as ws:
            frame = ws.receive_json()
            assert frame["type"] == "message"
            assert frame.get("queued") is True
            assert asyncio.run(bm.decrypt("alice", Envelope.from_dict(frame["envelope"]))) == b"offline hello"

            # --- real-time delivery: Bob is connected now ---
            env2 = asyncio.run(am.encrypt("bob", b"live hello"))
            r = tc.post(
                "/api/v1/messages",
                json={"client_msg_id": "o2", "recipient": "bob", "envelope": env2.to_dict()},
                headers=ah,
            )
            assert r.json()["status"] == "delivered"
            frame2 = ws.receive_json()
            assert frame2["type"] == "message"
            assert asyncio.run(bm.decrypt("alice", Envelope.from_dict(frame2["envelope"]))) == b"live hello"


def test_ws_rejects_bad_token():
    import pytest
    from starlette.websockets import WebSocketDisconnect

    with TestClient(app) as tc:
        # The server closes the socket with a policy-violation code before accept.
        with pytest.raises(WebSocketDisconnect) as exc:
            with tc.websocket_connect("/api/v1/ws?token=garbage"):
                pass
        assert exc.value.code == 1008


def test_ws_send_and_ack():
    with TestClient(app) as tc:
        a = _register(tc, "alice")
        b = _register(tc, "bob")
        ah = {"Authorization": f"Bearer {a['access_token']}"}
        bh = {"Authorization": f"Bearer {b['access_token']}"}
        am, bm = SessionManager("alice"), SessionManager("bob")
        _publish(tc, ah, am)
        _publish(tc, bh, bm)

        bundle = bundle_from_bundle_response(tc.get("/api/v1/keys/bundle/bob", headers=ah).json())
        env = asyncio.run(am.encrypt("bob", b"over the socket", peer_bundle=bundle))

        with tc.websocket_connect(f"/api/v1/ws?token={a['access_token']}") as aws:
            aws.send_json({"type": "send", "client_msg_id": "ws1", "recipient": "bob", "envelope": env.to_dict()})
            ack = aws.receive_json()
            assert ack["type"] == "ack"
            assert ack["client_msg_id"] == "ws1"
