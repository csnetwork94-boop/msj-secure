"""FastAPI application factory and entrypoint."""

from __future__ import annotations

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse

from .config import get_settings
from .database import init_models
from .logging_setup import configure_logging
from .ratelimit import limiter
from .routers import auth, devices, keys, messages, users
from .ws import router as ws_router

logger = logging.getLogger("msj.app")


@asynccontextmanager
async def lifespan(app: FastAPI):
    settings = get_settings()
    configure_logging(json_output=settings.is_production)
    if settings.is_production and len(settings.jwt_secret) < 32:
        raise RuntimeError("MSJ_JWT_SECRET must be set to a strong value in production")
    if settings.is_production and settings.database_url.startswith("sqlite"):
        logger.warning("Production is configured to use SQLite; use PostgreSQL instead.")
    await init_models()
    logger.info("startup complete", extra={"env": settings.environment})
    yield
    await limiter.reset()


def create_app() -> FastAPI:
    settings = get_settings()
    app = FastAPI(title=settings.app_name, version="1.0.0", lifespan=lifespan)

    app.include_router(auth.router)
    app.include_router(keys.router)
    app.include_router(users.router)
    app.include_router(messages.router)
    app.include_router(devices.router)
    app.include_router(ws_router)

    @app.middleware("http")
    async def security_headers(request: Request, call_next):
        # Enforce TLS in production, honouring a reverse proxy's X-Forwarded-Proto.
        if settings.require_tls and settings.is_production:
            proto = request.headers.get("x-forwarded-proto", request.url.scheme)
            if proto != "https":
                return JSONResponse(status_code=400, content={"detail": "TLS required"})
        response = await call_next(request)
        response.headers["X-Content-Type-Options"] = "nosniff"
        response.headers["X-Frame-Options"] = "DENY"
        response.headers["Referrer-Policy"] = "no-referrer"
        response.headers["Cache-Control"] = "no-store"
        if settings.is_production:
            response.headers["Strict-Transport-Security"] = "max-age=63072000; includeSubDomains"
        return response

    @app.get("/healthz", tags=["ops"])
    async def healthz() -> dict:
        return {"status": "ok"}

    @app.get("/", include_in_schema=False)
    async def root() -> dict:
        return {"service": settings.app_name, "see": "/docs"}

    return app


app = create_app()
