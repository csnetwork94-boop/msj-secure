"""Public key bundle distribution (X3DH).

The server stores and hands out *public* key material only: a user's identity
key, signed pre key, the signature over it, and a pool of one-time pre keys.
It never sees any private key.
"""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, status
from sqlalchemy import func, select

from ..deps import CurrentUser, DbSession, SettingsDep
from ..models import IdentityBundle, PreKey
from ..schemas import BundleResponse, BundleUpload, PreKeyRefill
from ..services import get_user_by_username

router = APIRouter(prefix="/api/v1/keys", tags=["keys"])


@router.put("/bundle", status_code=status.HTTP_204_NO_CONTENT, response_model=None)
async def publish_bundle(body: BundleUpload, user: CurrentUser, session: DbSession, settings: SettingsDep) -> None:
    """Publish or rotate the caller's X3DH bundle, optionally adding pre keys."""
    bundle = await session.get(IdentityBundle, user.id)
    if bundle is None:
        bundle = IdentityBundle(user_id=user.id)
        session.add(bundle)
    bundle.identity_key = body.identity_key
    bundle.signed_pre_key = body.signed_pre_key
    bundle.signed_pre_key_sig = body.signed_pre_key_sig

    for pk in body.pre_keys:
        session.add(PreKey(user_id=user.id, public_key=pk))

    await session.flush()
    await _enforce_pre_key_cap(session, user.id, settings.max_published_pre_keys)
    await session.commit()


@router.post("/prekeys", status_code=status.HTTP_204_NO_CONTENT, response_model=None)
async def refill_prekeys(body: PreKeyRefill, user: CurrentUser, session: DbSession, settings: SettingsDep) -> None:
    if await session.get(IdentityBundle, user.id) is None:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="publish a bundle first")
    for pk in body.pre_keys:
        session.add(PreKey(user_id=user.id, public_key=pk))
    await session.flush()
    await _enforce_pre_key_cap(session, user.id, settings.max_published_pre_keys)
    await session.commit()


@router.get("/status")
async def key_status(user: CurrentUser, session: DbSession, settings: SettingsDep) -> dict:
    bundle = await session.get(IdentityBundle, user.id)
    unused = await _count_unused(session, user.id)
    return {
        "has_bundle": bundle is not None,
        "unused_pre_keys": unused,
        "low": unused <= settings.pre_key_low_watermark,
    }


@router.get("/bundle/{username}", response_model=BundleResponse)
async def get_bundle(username: str, user: CurrentUser, session: DbSession) -> BundleResponse:
    """Fetch another user's bundle, consuming one one-time pre key if available."""
    target = await get_user_by_username(session, username)
    if target is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="user not found")
    bundle = await session.get(IdentityBundle, target.id)
    if bundle is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="user has not published keys")

    pre_key = (
        await session.execute(
            select(PreKey)
            .where(PreKey.user_id == target.id, PreKey.used.is_(False))
            .order_by(PreKey.created_at.asc())
            .limit(1)
        )
    ).scalar_one_or_none()
    if pre_key is not None:
        pre_key.used = True
        await session.commit()

    return BundleResponse(
        username=target.username,
        identity_key=bundle.identity_key,
        signed_pre_key=bundle.signed_pre_key,
        signed_pre_key_sig=bundle.signed_pre_key_sig,
        pre_key=pre_key.public_key if pre_key else None,
        pre_key_count=await _count_unused(session, target.id),
    )


async def _count_unused(session, user_id: str) -> int:
    return int(
        (
            await session.execute(
                select(func.count()).select_from(PreKey).where(PreKey.user_id == user_id, PreKey.used.is_(False))
            )
        ).scalar_one()
    )


async def _enforce_pre_key_cap(session, user_id: str, cap: int) -> None:
    """Drop the oldest *unused* pre keys beyond the cap to bound storage."""
    unused_ids = (
        (
            await session.execute(
                select(PreKey.id)
                .where(PreKey.user_id == user_id, PreKey.used.is_(False))
                .order_by(PreKey.created_at.asc())
            )
        )
        .scalars()
        .all()
    )
    overflow = len(unused_ids) - cap
    for pid in unused_ids[: max(overflow, 0)]:
        obj = await session.get(PreKey, pid)
        if obj is not None:
            await session.delete(obj)
