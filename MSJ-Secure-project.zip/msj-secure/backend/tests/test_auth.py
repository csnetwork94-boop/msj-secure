"""Authentication and account lifecycle tests."""

from __future__ import annotations

from .conftest import PASSWORD, register_account


async def test_register_and_me(client):
    acct = await register_account(client, "alice")
    me = await client.get("/api/v1/auth/me", headers=acct.headers)
    assert me.status_code == 200
    assert me.json()["username"] == "alice"


async def test_duplicate_username_rejected(client):
    await register_account(client, "bob")
    resp = await client.post(
        "/api/v1/auth/register",
        json={"username": "BOB", "password": PASSWORD, "device_name": "d"},
    )
    assert resp.status_code == 409


async def test_login_success_and_failure(client):
    await register_account(client, "carol")
    ok = await client.post("/api/v1/auth/login", json={"username": "carol", "password": PASSWORD})
    assert ok.status_code == 200
    bad = await client.post("/api/v1/auth/login", json={"username": "carol", "password": "wrongwrongwrong"})
    assert bad.status_code == 401
    unknown = await client.post("/api/v1/auth/login", json={"username": "nobody", "password": PASSWORD})
    assert unknown.status_code == 401


async def test_refresh_rotation_and_reuse_detection(client):
    acct = await register_account(client, "dave")
    rt = acct.tokens["refresh_token"]
    first = await client.post("/api/v1/auth/refresh", json={"refresh_token": rt})
    assert first.status_code == 200
    # Reusing the original (now rotated) token must fail and revoke the chain.
    reuse = await client.post("/api/v1/auth/refresh", json={"refresh_token": rt})
    assert reuse.status_code == 401
    # The freshly issued token is also revoked by reuse detection.
    second = first.json()["refresh_token"]
    after = await client.post("/api/v1/auth/refresh", json={"refresh_token": second})
    assert after.status_code == 401


async def test_logout_revokes_device_and_token(client):
    acct = await register_account(client, "erin")
    assert (await client.post("/api/v1/auth/logout", headers=acct.headers)).status_code == 204
    # Access token now fails because the device is revoked.
    assert (await client.get("/api/v1/auth/me", headers=acct.headers)).status_code == 401


async def test_change_password(client):
    acct = await register_account(client, "frank")
    r = await client.post(
        "/api/v1/auth/change-password",
        json={"current_password": PASSWORD, "new_password": "brandnewpass123"},
        headers=acct.headers,
    )
    assert r.status_code == 204
    assert (
        await client.post("/api/v1/auth/login", json={"username": "frank", "password": PASSWORD})
    ).status_code == 401
    assert (
        await client.post("/api/v1/auth/login", json={"username": "frank", "password": "brandnewpass123"})
    ).status_code == 200


async def test_delete_account(client):
    acct = await register_account(client, "gina")
    r = await client.post("/api/v1/auth/delete-account", json={"password": PASSWORD}, headers=acct.headers)
    assert r.status_code == 204
    assert (await client.post("/api/v1/auth/login", json={"username": "gina", "password": PASSWORD})).status_code == 401


async def test_weak_registration_rejected(client):
    resp = await client.post("/api/v1/auth/register", json={"username": "x", "password": "short"})
    assert resp.status_code == 422
