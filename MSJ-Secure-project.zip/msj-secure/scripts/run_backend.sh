#!/usr/bin/env bash
# Run the MSJ Secure backend locally (SQLite).
set -euo pipefail
here="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$here/backend"
export PYTHONPATH="$here/backend:$here/shared"
exec uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
