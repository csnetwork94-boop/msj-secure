# MSJ Secure

An online private messenger with a **Python + Kivy Android client** and a
**Python + FastAPI backend**, providing genuine **end-to-end encryption (E2EE)**.
The server relays and stores ciphertext only — it cannot read message content.

> **Status:** The backend, the shared E2EE core and the desktop-testable client
> logic are implemented and covered by an automated test suite that runs and
> passes in this repository. The Android APK has **not** been built here (no
> Android SDK/NDK toolchain is available in the build environment); the client
> source and `buildozer.spec` are provided, with an honest build guide in
> `docs/APK_BUILD.md`. This project has **not** been independently security
> audited — see `SECURITY.md`.

## What is implemented

- **Account & identity** — username + password registration/login, Argon2id
  password hashing, JWT access tokens, rotating refresh tokens with reuse
  detection, device/session management, logout, password change, account
  deletion and data export.
- **Key distribution** — publish/fetch X3DH public bundles, one-time pre-key
  pool with server-side consumption and refill.
- **One-to-one chat** — real-time text messaging over an authenticated
  WebSocket, plus a REST send path; message states (sending/sent/delivered/read)
  via receipts; conversation history with cursor pagination.
- **E2EE** — real Signal-style protocol: X3DH key agreement + Double Ratchet,
  with forward secrecy, out-of-order delivery, duplicate-message rejection and
  per-conversation session state persisted encrypted at rest on the client.
- **Offline delivery** — ciphertext is queued server-side and flushed when the
  recipient reconnects.
- **Safety numbers** — a shared 60-digit value for out-of-band key verification.
- **Reliability** — reconnect/backoff on the client, structured redacting logs,
  rate limiting, input validation, TLS enforcement in production.

## Explicitly deferred (not implemented)

The brief requires that these be deferred rather than shipped insecurely, and
they are:

- **Group messaging** — deferred. Group E2EE requires secure group key
  distribution and membership-change handling; not implemented.
- **Encrypted attachments** — deferred. The design (client-side content key,
  ciphertext-only upload, key delivered inside the E2EE message) is documented
  in `docs/ARCHITECTURE.md`, but the feature is disabled so no plaintext file is
  ever uploaded.

## Project layout

```
msj-secure/
├── shared/msj_crypto/     # E2EE core: X3DH + Double Ratchet (used by client & tests)
├── backend/               # FastAPI service
│   ├── app/               #   application code (models, routers, ws, security)
│   ├── migrations/        #   Alembic migrations
│   ├── tests/             #   automated test suite (pytest)
│   ├── Dockerfile
│   └── requirements*.txt
├── client/                # Kivy Android client
│   ├── main.py            #   Kivy app entrypoint
│   ├── msj_client/        #   api / crypto_adapter / storage / i18n (desktop-testable)
│   ├── ui/msj.kv          #   UI layout
│   └── buildozer.spec     #   Android packaging config
├── docs/                  # architecture, deployment, build, backup, checklists
├── scripts/               # helper scripts
├── docker-compose.yml
├── .env.example
└── SECURITY.md
```

## Quickstart (local development)

Requires Python 3.12.

```bash
# 1. Shared E2EE core + backend dependencies
python -m pip install -r backend/requirements-dev.txt

# 2. Configure (development defaults work out of the box)
cp .env.example backend/.env      # optional; edit as needed

# 3. Run the backend (SQLite by default)
cd backend
PYTHONPATH=.:../shared uvicorn app.main:app --reload
# API docs: http://127.0.0.1:8000/docs
```

For a PostgreSQL stack with Docker:

```bash
export MSJ_JWT_SECRET="$(python -c 'import secrets;print(secrets.token_urlsafe(48))')"
docker compose up --build
```

## Running the tests

```bash
cd backend
PYTHONPATH=.:../shared python -m pytest -q
```

This runs unit tests for the crypto core, authentication, authorization,
message routing, negative/abuse cases, the WebSocket relay, the client stack,
and a full **E2EE integration test** that inspects the database to prove the
server holds only ciphertext and public keys.

Linting and formatting:

```bash
python -m ruff check shared backend
python -m ruff format --check shared backend
```

## Building the Android app

Two options:

- **On a Linux machine:** run `scripts/prepare_android_build.sh`, then
  `buildozer -v android debug`. See **`docs/APK_BUILD.md`**.
- **No computer needed — GitHub Actions:** push the project to a GitHub repo and
  the included workflow (`.github/workflows/android.yml`) builds the APK and
  offers it as a download. See **`docs/GITHUB_ACTIONS_BUILD.md`**.

The APK has not been built or verified in this environment.

## Security

Read **`SECURITY.md`** for the threat model, the exact protocol/library choice,
key management, metadata limitations, and the deployment checklist. This
software has not been independently audited.
