"""Protocol constants shared by client and backend test harness.

These values are *not* secrets. Changing any of them changes the wire format
and the derived key material, so they must be versioned and kept identical on
both sides of a conversation.
"""

# Application identifier fed into X3DH's HKDF (the ``info`` parameter).
APP_INFO = b"MSJ Secure X3DH v1"

# Fixed constant fed into the Double Ratchet's message KDF chains, per the
# Signal Double Ratchet specification (KDF chains).
MESSAGE_CHAIN_CONSTANT = b"\x00" * 32

# Double Ratchet tuning. ``DOS_PROTECTION_THRESHOLD`` bounds how many skipped
# message keys are computed in one step; ``MAX_SKIPPED_MESSAGE_KEYS`` bounds how
# many are retained for out-of-order delivery.
DOS_PROTECTION_THRESHOLD = 1000
MAX_SKIPPED_MESSAGE_KEYS = 2000

# Envelope format version. Bump on any incompatible change.
PROTOCOL_VERSION = 1
