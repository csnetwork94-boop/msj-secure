"""Async SQLAlchemy engine, session factory and declarative base."""

from __future__ import annotations

from typing import AsyncIterator

from sqlalchemy.ext.asyncio import (
    AsyncSession,
    async_sessionmaker,
    create_async_engine,
)
from sqlalchemy.orm import DeclarativeBase

from .config import get_settings


class Base(DeclarativeBase):
    pass


_settings = get_settings()

# In tests we use a NullPool so each operation opens a fresh connection in the
# running event loop. This keeps the suite robust when a synchronous
# TestClient (its own loop) and pytest-asyncio (another loop) share one engine.
_engine_kwargs: dict = {"echo": False, "pool_pre_ping": True}
if _settings.environment == "test":
    from sqlalchemy.pool import NullPool

    _engine_kwargs = {"echo": False, "poolclass": NullPool}

engine = create_async_engine(_settings.database_url, **_engine_kwargs)

SessionLocal = async_sessionmaker(engine, expire_on_commit=False, class_=AsyncSession)


async def get_session() -> AsyncIterator[AsyncSession]:
    async with SessionLocal() as session:
        yield session


async def init_models() -> None:
    """Create tables. In production use Alembic migrations instead."""
    from . import models  # noqa: F401  (ensure models are imported)

    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
