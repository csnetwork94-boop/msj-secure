"""User discovery: search by username prefix without exposing private data."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Query, status
from sqlalchemy import select

from ..deps import CurrentUser, DbSession
from ..models import IdentityBundle, User
from ..schemas import UserPublic, UserSearchResponse

router = APIRouter(prefix="/api/v1/users", tags=["users"])


@router.get("/search", response_model=UserSearchResponse)
async def search(
    user: CurrentUser,
    session: DbSession,
    q: str = Query(min_length=1, max_length=32),
    limit: int = Query(default=20, ge=1, le=50),
    offset: int = Query(default=0, ge=0),
) -> UserSearchResponse:
    needle = q.strip().lower()
    rows = (
        (
            await session.execute(
                select(User)
                .where(User.username_lower.like(f"{needle}%"), User.is_active.is_(True))
                .order_by(User.username_lower.asc())
                .offset(offset)
                .limit(limit + 1)
            )
        )
        .scalars()
        .all()
    )

    has_more = len(rows) > limit
    rows = rows[:limit]
    results = [UserPublic(id=u.id, username=u.username) for u in rows]
    return UserSearchResponse(results=results, next_offset=(offset + limit) if has_more else None)


@router.get("/{username}")
async def get_user(username: str, user: CurrentUser, session: DbSession) -> dict:
    target = (
        await session.execute(select(User).where(User.username_lower == username.strip().lower()))
    ).scalar_one_or_none()
    if target is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="user not found")
    has_bundle = await session.get(IdentityBundle, target.id) is not None
    # Only public, non-sensitive fields.
    return {"id": target.id, "username": target.username, "has_keys": has_bundle}
