"""Encrypted-at-rest storage for private key material and session state.

Two backends are provided:

* :class:`FileSecureStore` — portable, always available. State is encrypted with
  AES-256-GCM under a key derived from the user's passphrase via scrypt, with a
  fresh random salt. Used on desktop and in tests.
* :class:`AndroidKeystoreKeyProvider` — best-effort hardware-backed protection on
  Android, using the Android Keystore through ``pyjnius``. If it is unavailable
  (as in this desktop environment) it degrades gracefully to the file store.

Threat model note: without a user passphrase or a hardware keystore, an attacker
with root access to an unlocked device can read app-private storage. See
SECURITY.md for the full discussion.
"""
from __future__ import annotations

import base64
import json
import os
import secrets
from pathlib import Path
from typing import Optional

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt

_SCRYPT_N = 2**15
_SCRYPT_R = 8
_SCRYPT_P = 1
_KEY_LEN = 32
_NONCE_LEN = 12
_SALT_LEN = 16


def _derive_key(passphrase: str, salt: bytes) -> bytes:
    return Scrypt(salt=salt, length=_KEY_LEN, n=_SCRYPT_N, r=_SCRYPT_R, p=_SCRYPT_P).derive(
        passphrase.encode("utf-8")
    )


class StorageError(Exception):
    """Raised when stored state cannot be read or decrypted."""


class FileSecureStore:
    """Encrypted JSON blob on disk."""

    def __init__(self, path: str | Path, passphrase: str) -> None:
        self.path = Path(path)
        self.passphrase = passphrase

    def _load_raw(self) -> Optional[dict]:
        if not self.path.exists():
            return None
        try:
            wrapper = json.loads(self.path.read_text("utf-8"))
            salt = base64.b64decode(wrapper["salt"])
            nonce = base64.b64decode(wrapper["nonce"])
            ciphertext = base64.b64decode(wrapper["data"])
            key = _derive_key(self.passphrase, salt)
            plaintext = AESGCM(key).decrypt(nonce, ciphertext, None)
            return json.loads(plaintext.decode("utf-8"))
        except (InvalidTag, KeyError, ValueError) as exc:
            raise StorageError("could not decrypt local state (wrong passphrase or corrupt data)") from exc

    def load(self) -> Optional[dict]:
        return self._load_raw()

    def save(self, data: dict) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        salt = secrets.token_bytes(_SALT_LEN)
        nonce = secrets.token_bytes(_NONCE_LEN)
        key = _derive_key(self.passphrase, salt)
        ciphertext = AESGCM(key).encrypt(nonce, json.dumps(data).encode("utf-8"), None)
        wrapper = {
            "v": 1,
            "kdf": "scrypt",
            "salt": base64.b64encode(salt).decode(),
            "nonce": base64.b64encode(nonce).decode(),
            "data": base64.b64encode(ciphertext).decode(),
        }
        # Write atomically.
        tmp = self.path.with_suffix(self.path.suffix + ".tmp")
        tmp.write_text(json.dumps(wrapper), "utf-8")
        os.replace(tmp, self.path)

    def delete(self) -> None:
        if self.path.exists():
            self.path.unlink()


class AndroidKeystoreKeyProvider:
    """Best-effort Android Keystore wrapper for a local data key.

    On a real Android device this creates (or loads) an AES key inside the
    Android Keystore and uses it to wrap the data-encryption key, so the data
    key is protected by hardware-backed storage where the device supports it.

    This requires ``pyjnius`` and an Android runtime. Where those are absent
    (desktop, CI) ``available`` is ``False`` and callers fall back to the
    passphrase-derived file store.
    """

    KEYSTORE_ALIAS = "msj_secure_master"

    def __init__(self) -> None:
        self.available = False
        self._autoclass = None
        try:  # pragma: no cover - Android-only path
            from jnius import autoclass  # type: ignore

            self._autoclass = autoclass
            self.available = True
        except Exception:
            self.available = False

    def wrap(self, data_key: bytes) -> bytes:  # pragma: no cover - Android-only
        if not self.available:
            raise StorageError("Android Keystore not available on this platform")
        raise StorageError(
            "Android Keystore wrapping must be implemented against the target "
            "device's API level; see SECURITY.md for the recommended approach."
        )

    def unwrap(self, wrapped: bytes) -> bytes:  # pragma: no cover - Android-only
        if not self.available:
            raise StorageError("Android Keystore not available on this platform")
        raise StorageError("Android Keystore unwrapping not implemented in this build")
