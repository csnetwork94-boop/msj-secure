# Building the Android APK

The APK has **not** been built in the development environment used to write this
project — there is no Android SDK/NDK toolchain there, and Buildozer downloads
several GB of dependencies. The instructions below are the supported path. Only
claim a successful APK build once you have actually produced and installed one.

## Prerequisites

- A **Linux** machine or VM (Ubuntu 20.04/22.04 recommended). Windows builds are
  not supported by python-for-android; use WSL2 or a Linux VM. Termux on Android
  is not a reliable APK build environment.
- ~10 GB free disk, a few GB of RAM, and internet access.
- Build tools:

```bash
sudo apt update
sudo apt install -y git zip unzip openjdk-17-jdk python3-pip python3-venv \
    autoconf libtool pkg-config zlib1g-dev libncurses5-dev libtinfo6 \
    cmake libffi-dev libssl-dev
```

## Build steps

```bash
# 1. Copy the shared E2EE core into the client tree (Buildozer packages it).
./scripts/prepare_android_build.sh

# 2. Install Buildozer and Cython in a virtualenv
python3 -m venv .venv && . .venv/bin/activate
pip install --upgrade pip
pip install buildozer cython

# 3. Build the debug APK (first run downloads the SDK/NDK; allow 30–60 min)
cd client
buildozer -v android debug
```

The APK is written to `client/bin/msjsecure-1.0.0-debug.apk` (path printed by
Buildozer). Install it on a device with:

```bash
adb install client/bin/msjsecure-1.0.0-debug.apk
```

For a release build, configure a keystore and run `buildozer android release`.

## Known Android-build caveats (honest list)

- **`xeddsa` is a cffi C extension.** python-for-android has ready recipes for
  `cffi` and `cryptography`, but **`xeddsa` likely needs a custom recipe** (it
  compiles a small C library). If the build fails on `xeddsa`, add a recipe
  under `client/.buildozer/.../recipes/` (copy the `cffi` recipe and adapt) or
  vendor the C sources. This is the most likely build blocker and is called out
  rather than hidden.
- **`cryptography`** requires the `openssl` recipe (already listed in
  `buildozer.spec`).
- **`pydantic`** (v2) pulls a compiled `pydantic-core` (Rust). If the p4a recipe
  for pydantic v2 is unavailable, pin pydantic v1-compatible usage or provide a
  recipe. Verify before release.
- **Networking**: the client uses `httpx` (pure Python) and `websockets` (pure
  Python) — no native deps beyond the above.
- **Permissions**: only `INTERNET` is requested. Keep it that way.

## After building

Run the manual two-device checklist in `docs/MANUAL_TEST_CHECKLIST.md`.
