#!/usr/bin/env bash
# Copy the shared E2EE core into the client tree so Buildozer packages it.
# Run this once before `buildozer android debug`.
set -euo pipefail
here="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
rm -rf "$here/client/msj_crypto"
cp -r "$here/shared/msj_crypto" "$here/client/msj_crypto"
echo "Copied shared/msj_crypto -> client/msj_crypto"
