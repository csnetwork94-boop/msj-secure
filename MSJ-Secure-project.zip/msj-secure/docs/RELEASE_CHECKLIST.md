# Release checklist

## Before release

- [ ] `python -m ruff check shared backend` passes.
- [ ] `python -m ruff format --check shared backend` passes.
- [ ] `cd backend && PYTHONPATH=.:../shared python -m pytest -q` — all tests pass.
- [ ] E2EE integration test passes (server stores ciphertext only).
- [ ] Dependency versions reviewed and pinned; licences acceptable.
- [ ] `MSJ_JWT_SECRET` rotated and stored in a secret manager (never committed).
- [ ] No secrets in the repo (`git grep` for tokens/passwords; `.env` gitignored).

## Backend deploy

- [ ] `MSJ_ENVIRONMENT=production`, `MSJ_REQUIRE_TLS=true`.
- [ ] PostgreSQL in use; `alembic upgrade head` applied.
- [ ] TLS certificate valid; HTTP rejected/redirected; HSTS present.
- [ ] Rate limits tuned; shared limiter store if multi-instance.
- [ ] Log aggregation confirms redaction of tokens/keys/plaintext.
- [ ] Retention purge job scheduled.
- [ ] Backups configured and a restore has been tested.

## Android app

- [ ] `scripts/prepare_android_build.sh` run (shared core copied in).
- [ ] `buildozer android release` builds successfully (verify the `xeddsa`
      recipe issue in `docs/APK_BUILD.md` first).
- [ ] Release APK signed with the production keystore; keystore backed up.
- [ ] Only `INTERNET` permission present.
- [ ] App points at the production `https://`/`wss://` endpoint.
- [ ] `docs/MANUAL_TEST_CHECKLIST.md` executed on two physical devices.

## Communications

- [ ] Release notes state clearly that the app is **not independently audited**.
- [ ] Known limitations from `SECURITY.md` acknowledged.
