# Manual test checklist — two Android devices

Run on two physical Android devices (Device A and Device B) against the
production or staging backend. Tick each item.

## Setup

- [ ] Install the APK on both devices.
- [ ] Device A: register user `alice`.
- [ ] Device B: register user `bob`.
- [ ] Both devices show "Messages are end-to-end encrypted".

## Account & session

- [ ] Register rejects a duplicate username.
- [ ] Login with a wrong password fails; correct password succeeds.
- [ ] Device A "Active devices" lists only its own session(s).
- [ ] Revoking a device signs that device out (its token stops working).
- [ ] Password change forces re-login on other devices.

## Messaging (E2EE)

- [ ] A searches for `bob` and opens a conversation.
- [ ] A sends "hello"; B receives it in real time and reads it correctly.
- [ ] B replies; A receives and reads it correctly.
- [ ] Message states progress: sending → sent → delivered → read.
- [ ] Send several messages rapidly; none are lost or duplicated.
- [ ] Send messages out of order (e.g. toggle airplane mode); all decrypt.

## Offline delivery

- [ ] Put Device B in airplane mode.
- [ ] A sends three messages; they show as "sent" (queued), not delivered.
- [ ] Re-enable Device B's network; queued messages arrive and decrypt.

## Verification & safety number

- [ ] Open "Verify safety number" on both devices.
- [ ] Both devices show the **same** safety number for the conversation.

## Negative / abuse

- [ ] Send an oversized message/attachment attempt is rejected.
- [ ] Repeated failed logins eventually rate-limit (429).
- [ ] Tampering with network traffic (proxy) causes decryption failure, not
      silent corruption.

## Server blindness (operator check)

- [ ] Inspect the server database: the `messages.envelope` column contains only
      ciphertext; searching for a known plaintext phrase returns nothing.
- [ ] Confirm logs contain no plaintext, tokens, or key material.
