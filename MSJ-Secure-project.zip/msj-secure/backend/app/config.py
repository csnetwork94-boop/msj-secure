"""Application configuration, loaded from environment variables.

Every secret comes from the environment. There are no hard-coded production
secrets; the development defaults exist only to make local runs and the test
suite frictionless, and the app refuses to start in production without a real
JWT secret.
"""

from __future__ import annotations

import secrets
from functools import lru_cache
from typing import List

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_prefix="MSJ_", env_file=".env", extra="ignore")

    app_name: str = "MSJ Secure"
    environment: str = "development"  # development | production | test

    # Database
    database_url: str = "sqlite+aiosqlite:///./msj_dev.db"

    # Auth
    jwt_secret: str = Field(default_factory=lambda: secrets.token_urlsafe(48))
    jwt_algorithm: str = "HS256"
    access_token_ttl_minutes: int = 15
    refresh_token_ttl_days: int = 30

    # Data handling
    message_retention_days: int = 30
    max_message_envelope_bytes: int = 64 * 1024
    max_username_length: int = 32
    min_password_length: int = 10

    # Pre keys
    pre_key_low_watermark: int = 20
    max_published_pre_keys: int = 200

    # Rate limits (requests per window)
    rate_limit_auth_per_minute: int = 20
    rate_limit_messages_per_minute: int = 120
    rate_limit_default_per_minute: int = 240

    # TLS
    require_tls: bool = False  # set true in production; see SECURITY.md

    cors_allow_origins: List[str] = []

    @field_validator("environment")
    @classmethod
    def _check_env(cls, v: str) -> str:
        if v not in {"development", "production", "test"}:
            raise ValueError("environment must be development, production or test")
        return v

    @property
    def is_production(self) -> bool:
        return self.environment == "production"


@lru_cache
def get_settings() -> Settings:
    return Settings()
