"""Authorization tests: users must not reach others' data."""

from __future__ import annotations

from .conftest import fetch_bundle, publish_bundle, register_account


async def test_missing_and_invalid_tokens(client):
    assert (await client.get("/api/v1/auth/me")).status_code == 401
    assert (await client.get("/api/v1/auth/me", headers={"Authorization": "Bearer nope"})).status_code == 401


async def test_cannot_ack_others_messages(client):
    alice = await register_account(client, "alice")
    bob = await register_account(client, "bob")
    carol = await register_account(client, "carol")
    await publish_bundle(client, alice)
    await publish_bundle(client, bob)
    await publish_bundle(client, carol)

    bundle = await fetch_bundle(client, alice, "bob")
    env = await alice.manager.encrypt("bob", b"hi bob", peer_bundle=bundle)
    sent = await client.post(
        "/api/v1/messages",
        json={"client_msg_id": "m1", "recipient": "bob", "envelope": env.to_dict()},
        headers=alice.headers,
    )
    assert sent.status_code == 201
    msg_id = sent.json()["id"]

    # Carol is not the recipient -> forbidden.
    r = await client.post(f"/api/v1/messages/{msg_id}/receipt", json={"status": "read"}, headers=carol.headers)
    assert r.status_code == 403


async def test_revoked_device_token_rejected(client):
    alice = await register_account(client, "alice")
    devices = await client.get("/api/v1/devices", headers=alice.headers)
    device_id = devices.json()[0]["id"]
    assert (await client.delete(f"/api/v1/devices/{device_id}", headers=alice.headers)).status_code == 204
    assert (await client.get("/api/v1/auth/me", headers=alice.headers)).status_code == 401


async def test_cannot_fetch_bundle_of_unknown_user(client):
    alice = await register_account(client, "alice")
    r = await client.get("/api/v1/keys/bundle/ghost", headers=alice.headers)
    assert r.status_code == 404
