"""Shared pytest fixtures and helpers for the backend test suite."""

from __future__ import annotations

import asyncio
import os
import pathlib
import sys

ROOT = pathlib.Path(__file__).resolve().parents[2]  # .../msj-secure
sys.path.insert(0, str(ROOT / "backend"))
sys.path.insert(0, str(ROOT / "shared"))
sys.path.insert(0, str(ROOT / "client"))

# Configure the app for tests *before* importing it.
os.environ["MSJ_ENVIRONMENT"] = "test"
os.environ["MSJ_DATABASE_URL"] = "sqlite+aiosqlite:///./test_msj.db"
os.environ["MSJ_JWT_SECRET"] = "test-secret-" + "x" * 40
os.environ["MSJ_REQUIRE_TLS"] = "false"
# Small auth limit so the rate-limit test is fast; generous message limit.
os.environ["MSJ_RATE_LIMIT_AUTH_PER_MINUTE"] = "5"
os.environ["MSJ_RATE_LIMIT_MESSAGES_PER_MINUTE"] = "100000"

import httpx  # noqa: E402
import pytest  # noqa: E402
from app.database import Base, engine  # noqa: E402
from app.main import app as fastapi_app  # noqa: E402
from app.ratelimit import limiter  # noqa: E402
from msj_crypto import SessionManager, bundle_from_bundle_response, bundle_to_wire  # noqa: E402

PASSWORD = "supersecret123"


@pytest.fixture(autouse=True)
def _fresh_db():
    """Recreate the schema and clear rate-limit state before every test."""

    async def _reset() -> None:
        async with engine.begin() as conn:
            await conn.run_sync(Base.metadata.drop_all)
            await conn.run_sync(Base.metadata.create_all)

    asyncio.run(_reset())
    asyncio.run(limiter.reset())
    yield


@pytest.fixture
async def client():
    transport = httpx.ASGITransport(app=fastapi_app)
    async with httpx.AsyncClient(transport=transport, base_url="http://test") as c:
        yield c


class Account:
    def __init__(self, username: str, tokens: dict, manager: SessionManager):
        self.username = username
        self.tokens = tokens
        self.manager = manager

    @property
    def headers(self) -> dict:
        return {"Authorization": f"Bearer {self.tokens['access_token']}"}


async def register_account(client: httpx.AsyncClient, username: str, password: str = PASSWORD) -> Account:
    resp = await client.post(
        "/api/v1/auth/register",
        json={"username": username, "password": password, "device_name": "test-device", "platform": "test"},
    )
    assert resp.status_code == 201, resp.text
    return Account(username, resp.json(), SessionManager(username))


async def publish_bundle(client: httpx.AsyncClient, account: Account) -> None:
    wire = bundle_to_wire(account.manager.bundle)
    resp = await client.put("/api/v1/keys/bundle", json=wire, headers=account.headers)
    assert resp.status_code == 204, resp.text


async def fetch_bundle(client: httpx.AsyncClient, requester: Account, target_username: str):
    resp = await client.get(f"/api/v1/keys/bundle/{target_username}", headers=requester.headers)
    assert resp.status_code == 200, resp.text
    return bundle_from_bundle_response(resp.json())
