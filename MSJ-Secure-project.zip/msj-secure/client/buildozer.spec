[app]

# (str) Title shown under the app icon
title = MSJ Secure

# (str) Package name / Java namespace
package.name = msjsecure

# (str) Package domain (needs to be unique; reverse-DNS)
package.domain = org.msjsecure

# (str) Source directory for the build
source.dir = .

# (list) File extensions to include from the source dir
source.include_exts = py,kv,png,jpg,atlas,json

# Include the client package, the UI and the shared crypto core.
# NOTE: run scripts/prepare_android_build.sh first — it copies shared/msj_crypto
# into this directory so it is packaged with the app.
source.include_patterns = main.py, msj_client/**, ui/**, msj_crypto/**

# (str) Version
version = 1.0.0

# (list) Python dependencies. python-for-android resolves pure-Python packages
# from PyPI automatically; cffi/cryptography/openssl have dedicated recipes.
# See docs/APK_BUILD.md for the caveat about xeddsa (a cffi C extension).
requirements = python3,kivy==2.3.0,cffi,cryptography,openssl,pydantic,typing-extensions,annotated-types,httpx,httpcore,anyio,sniffio,h11,certifi,idna,doubleratchet,x3dh,xeddsa

# (str) Presplash / icon (add real assets before release)
# presplash.filename = %(source.dir)s/assets/presplash.png
# icon.filename = %(source.dir)s/assets/icon.png

# (str) Orientation
orientation = portrait

# (bool) Fullscreen
fullscreen = 0

# (list) Android permissions — kept to the minimum required.
android.permissions = INTERNET

# (int) Target API level (Google Play currently requires a recent target)
android.api = 34

# (int) Minimum API level supported
android.minapi = 24

# (int) Android NDK API level
android.ndk_api = 24

# (list) CPU architectures to build
android.archs = arm64-v8a, armeabi-v7a

# (bool) Allow app data backup (disabled: keep encrypted state on-device)
android.allow_backup = 0

# (str) Java class for the application
android.entrypoint = org.kivy.android.PythonActivity

# (list) Services (none)
# services =

# (str) Log level during build: 2 = info
log_level = 2

[buildozer]
log_level = 2
warn_on_root = 1
