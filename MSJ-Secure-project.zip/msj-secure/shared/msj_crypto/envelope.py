"""Wire representation of an encrypted message.

An :class:`Envelope` is the exact JSON-serialisable structure the backend
relays and stores. It contains only ciphertext and public protocol data — never
plaintext, never a private key.

The first message in a conversation additionally carries the X3DH header so the
recipient can complete the key agreement. Subsequent messages carry only the
Double Ratchet header.
"""

from __future__ import annotations

import base64
import json
from dataclasses import dataclass, field
from typing import Any, Dict, Optional

from doubleratchet import EncryptedMessage
from doubleratchet import Header as RatchetHeader
from x3dh import Bundle
from x3dh import Header as X3DHHeader

from .constants import PROTOCOL_VERSION


def _b64(data: bytes) -> str:
    return base64.b64encode(data).decode("ascii")


def _unb64(data: str) -> bytes:
    return base64.b64decode(data.encode("ascii"))


@dataclass
class X3DHHeaderWire:
    """JSON-serialisable form of the X3DH initiation header."""

    identity_key: bytes
    ephemeral_key: bytes
    signed_pre_key: bytes
    pre_key: Optional[bytes] = None

    def to_header(self) -> X3DHHeader:
        return X3DHHeader(
            identity_key=self.identity_key,
            ephemeral_key=self.ephemeral_key,
            signed_pre_key=self.signed_pre_key,
            pre_key=self.pre_key,
        )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "identity_key": _b64(self.identity_key),
            "ephemeral_key": _b64(self.ephemeral_key),
            "signed_pre_key": _b64(self.signed_pre_key),
            "pre_key": None if self.pre_key is None else _b64(self.pre_key),
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "X3DHHeaderWire":
        pre_key = d.get("pre_key")
        return cls(
            identity_key=_unb64(d["identity_key"]),
            ephemeral_key=_unb64(d["ephemeral_key"]),
            signed_pre_key=_unb64(d["signed_pre_key"]),
            pre_key=None if pre_key is None else _unb64(pre_key),
        )


@dataclass
class Envelope:
    """A single encrypted message ready for transport."""

    ratchet_pub: bytes
    previous_sending_chain_length: int
    sending_chain_length: int
    ciphertext: bytes
    x3dh: Optional[X3DHHeaderWire] = None
    version: int = field(default=PROTOCOL_VERSION)

    @classmethod
    def from_ratchet(
        cls,
        message: EncryptedMessage,
        x3dh_header: Optional[X3DHHeader] = None,
    ) -> "Envelope":
        wire = None
        if x3dh_header is not None:
            wire = X3DHHeaderWire(
                identity_key=x3dh_header.identity_key,
                ephemeral_key=x3dh_header.ephemeral_key,
                signed_pre_key=x3dh_header.signed_pre_key,
                pre_key=x3dh_header.pre_key,
            )
        return cls(
            ratchet_pub=message.header.ratchet_pub,
            previous_sending_chain_length=message.header.previous_sending_chain_length,
            sending_chain_length=message.header.sending_chain_length,
            ciphertext=message.ciphertext,
            x3dh=wire,
        )

    def to_ratchet(self) -> EncryptedMessage:
        return EncryptedMessage(
            header=RatchetHeader(
                ratchet_pub=self.ratchet_pub,
                previous_sending_chain_length=self.previous_sending_chain_length,
                sending_chain_length=self.sending_chain_length,
            ),
            ciphertext=self.ciphertext,
        )

    def to_dict(self) -> Dict[str, Any]:
        return {
            "v": self.version,
            "ratchet_pub": _b64(self.ratchet_pub),
            "pn": self.previous_sending_chain_length,
            "n": self.sending_chain_length,
            "ciphertext": _b64(self.ciphertext),
            "x3dh": None if self.x3dh is None else self.x3dh.to_dict(),
        }

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "Envelope":
        version = int(d.get("v", PROTOCOL_VERSION))
        if version != PROTOCOL_VERSION:
            raise ValueError(f"Unsupported envelope version: {version}")
        x3dh = d.get("x3dh")
        return cls(
            ratchet_pub=_unb64(d["ratchet_pub"]),
            previous_sending_chain_length=int(d["pn"]),
            sending_chain_length=int(d["n"]),
            ciphertext=_unb64(d["ciphertext"]),
            x3dh=None if x3dh is None else X3DHHeaderWire.from_dict(x3dh),
            version=version,
        )

    def to_json(self) -> str:
        return json.dumps(self.to_dict(), separators=(",", ":"))

    @classmethod
    def from_json(cls, s: str) -> "Envelope":
        return cls.from_dict(json.loads(s))


def bundle_to_wire(bundle: "Bundle") -> Dict[str, Any]:
    """Serialise an X3DH public bundle for upload to the backend."""
    return {
        "identity_key": _b64(bundle.identity_key),
        "signed_pre_key": _b64(bundle.signed_pre_key),
        "signed_pre_key_sig": _b64(bundle.signed_pre_key_sig),
        "pre_keys": [_b64(p) for p in bundle.pre_keys],
    }


def bundle_from_wire(d: Dict[str, Any]) -> "Bundle":
    """Reconstruct an X3DH public bundle from backend data."""
    return Bundle(
        identity_key=_unb64(d["identity_key"]),
        signed_pre_key=_unb64(d["signed_pre_key"]),
        signed_pre_key_sig=_unb64(d["signed_pre_key_sig"]),
        pre_keys=frozenset(_unb64(p) for p in d.get("pre_keys", [])),
    )


def bundle_from_bundle_response(d: Dict[str, Any]) -> "Bundle":
    """Build a bundle from the backend's ``/keys/bundle/{username}`` response.

    The backend hands out at most one one-time pre key per request.
    """
    pre = d.get("pre_key")
    return Bundle(
        identity_key=_unb64(d["identity_key"]),
        signed_pre_key=_unb64(d["signed_pre_key"]),
        signed_pre_key_sig=_unb64(d["signed_pre_key_sig"]),
        pre_keys=frozenset({_unb64(pre)}) if pre else frozenset(),
    )
