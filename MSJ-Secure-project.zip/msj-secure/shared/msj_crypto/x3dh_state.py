"""X3DH state wrapper.

Subclasses :class:`x3dh.State` (the package's automated state manager) to
supply the two application-defined hooks it requires:

* ``_encode_public_key`` — a length-prefixed, unambiguous encoding of a public
  key that includes the curve, so two keys never collide.
* ``_publish_bundle`` — the hook X3DH calls whenever the public bundle changes.
  We simply record the latest bundle; the application reads ``state.bundle``
  explicitly after key generation and publishes it to the backend.

No key material is ever logged or serialised here beyond what the library
already does.
"""

from __future__ import annotations

from x3dh import Bundle, HashFunction, IdentityKeyFormat, State

from .constants import APP_INFO

_CURVE25519_PREFIX = b"\x05"
_ED25519_PREFIX = b"\x06"


class X3DHState(State):
    """Concrete X3DH state using Curve25519 identity keys and SHA-256."""

    def _encode_public_key(self, key_format: IdentityKeyFormat, pub: bytes) -> bytes:
        if key_format is IdentityKeyFormat.CURVE_25519:
            return _CURVE25519_PREFIX + pub
        if key_format is IdentityKeyFormat.ED_25519:
            return _ED25519_PREFIX + pub
        raise ValueError(f"Unsupported identity key format: {key_format!r}")

    def _publish_bundle(self, bundle: Bundle) -> None:
        # Called by State.create and whenever the bundle changes. We retain the
        # most recent bundle so callers can pick it up; publishing to the
        # backend is an explicit, separate step.
        self.last_published_bundle = bundle

    @classmethod
    def new(
        cls,
        *,
        num_pre_keys: int = 100,
        signed_pre_key_rotation_period: int = 604800,
        pre_key_refill_threshold: int = 99,
        pre_key_refill_target: int = 100,
    ) -> "X3DHState":
        """Create a fresh state with a full complement of pre keys."""
        state = cls.create(
            identity_key_format=IdentityKeyFormat.CURVE_25519,
            hash_function=HashFunction.SHA_256,
            info=APP_INFO,
            signed_pre_key_rotation_period=signed_pre_key_rotation_period,
            pre_key_refill_threshold=pre_key_refill_threshold,
            pre_key_refill_target=pre_key_refill_target,
        )
        state.generate_pre_keys(num_pre_keys)
        return state

    @property
    def bundle(self) -> Bundle:
        return super().bundle
