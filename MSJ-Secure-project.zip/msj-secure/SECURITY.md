# Security Policy and Threat Model — MSJ Secure

This document describes what MSJ Secure protects against, how, and — just as
importantly — what it does **not** protect against. It is written to be honest
rather than reassuring.

> **Audit status:** This application has **not** been independently security
> audited. Do not describe it as audited, "military-grade", or
> production-secure. The cryptography is assembled from maintained, widely used
> libraries, but the integration has not been reviewed by a third party.

---

## 1. Security goals

1. **Message confidentiality** — only the sender's and recipient's devices can
   read message content. The server, and anyone who compromises the server, can
   read only ciphertext.
2. **Forward secrecy** — compromise of current keys does not expose past
   messages (provided the Double Ratchet has advanced).
3. **Authenticated encryption** — tampered or forged ciphertext is rejected.
4. **Account security** — passwords are never stored in plaintext; tokens are
   short-lived and revocable; sessions can be managed and revoked.
5. **Data minimisation** — the server stores the least data needed to operate.

## 2. Non-goals / what is NOT protected

- **Metadata.** The server necessarily learns account identities, who messages
  whom, message sizes and timing, delivery/read receipts, and device/session
  activity. E2EE does not hide this. Message *content* is protected; the
  *existence and pattern* of communication is not.
- **Compromised endpoints.** If a device is infected with malware, rooted, or
  unlocked-and-inspected, the plaintext on that device and its keys can be read.
  See §6 for the at-rest story.
- **Traffic analysis / censorship resistance.** Not addressed.
- **A malicious recipient.** Anyone you send a message to can copy it. E2EE
  cannot prevent that.
- **Denial of service.** Mitigated by rate limits but not fully solved.
- **Group messaging and attachments** are not implemented (see §8); no security
  claim is made for them.

## 3. Cryptographic protocol and libraries

MSJ Secure does **not** invent any cryptographic primitive or protocol. It
composes two maintained, MIT-licensed pure-Python implementations of the Signal
specifications:

| Purpose | Component | Version | Licence |
|---|---|---|---|
| Asynchronous key agreement | `x3dh` (X3DH) | 1.3.0 | MIT |
| Forward-secret ratchet | `doubleratchet` (Double Ratchet) | 1.1.0 | MIT |
| Primitives (X25519, HKDF-SHA256, AES-256-GCM) | `cryptography` | 50.0.2 | Apache-2.0 / BSD-3-Clause |
| XEdDSA signatures (used by `x3dh`) | `xeddsa` | 1.2.0 | MIT |

Protocol flow for a new conversation:

1. **X3DH** (Signal's Extended Triple Diffie-Hellman) — the initiator fetches the
   recipient's *public* bundle (identity key, signed pre-key + signature, and one
   one-time pre-key) and performs a triple/quadruple DH to derive a shared
   secret. The recipient completes the agreement from the header carried on the
   first message.
2. **Double Ratchet** — that shared secret seeds a root key. Each message is
   encrypted with a fresh message key derived by a symmetric-key ratchet, and
   new DH ratchet steps are taken as the conversation flows, giving forward
   secrecy and break-in recovery.

Primitives are the Signal-recommended ones: **X25519** for DH, **HKDF-SHA256**
for key derivation, and **AES-256-GCM** (random 96-bit nonce) for authenticated
encryption. Associated data binds each message to `sender|recipient`, so a
message cannot be replayed into a different conversation.

### Library-selection notes and limitations

- **Why not `libsignal`?** Signal's own library is a Rust/C library with no
  official, maintained PyPI wheel; it is impractical to package for a
  Python/Kivy Android app. `doubleratchet` + `x3dh` are the maintained Python
  implementations of the same specifications.
- These libraries implement the *protocols* but are smaller projects than
  `libsignal`; treat them accordingly and pin versions.
- **No XEdDSA change of heart**: signatures are used only for the signed
  pre-key, as in X3DH.

## 4. What the server sees and stores

- Account records: username, Argon2id password hash, timestamps.
- **Public** key material only: identity public key, signed pre-key + signature,
  and one-time pre-key *public* values.
- **Ciphertext envelopes** (opaque JSON) and delivery metadata.
- No plaintext message content, no private keys, no contact lists, no location.
- Administrators have **no** mechanism to decrypt messages and there is **no**
  backdoor. An admin can only operate accounts and read operational records.

The database stores `envelope` as opaque JSON; the code never parses its
cryptographic contents. The integration test asserts that the plaintext string
does not appear anywhere in the database after a message is sent.

## 5. Passwords, tokens and sessions

- Passwords: **Argon2id** via `argon2-cffi` (library defaults), never logged.
- Access tokens: **HS256 JWTs**, short-lived (`MSJ_ACCESS_TOKEN_TTL_MINUTES`,
  default 15). They are bearer tokens — always sent over TLS.
- Refresh tokens: 256-bit random, stored only as SHA-256 hashes, **rotated on
  every use**. Presenting an already-rotated token triggers reuse detection and
  revokes the device's whole token chain.
- Devices/sessions can be listed and revoked; a revoked device's tokens are
  rejected immediately.

## 6. Client key management and at-rest protection

- Private keys (identity key, signed pre-key, one-time pre-keys) and Double
  Ratchet session state live **only on the client** and are never transmitted.
- Local state is written **encrypted at rest**: AES-256-GCM under a key derived
  from the user's passphrase via **scrypt** (N=2¹⁵, r=8, p=1) with a fresh random
  salt (`client/msj_client/storage.py`).
- **Android Keystore limitation.** True hardware-backed protection requires the
  Android Keystore, which is reachable from Python only through JNI
  (`pyjnius`). `AndroidKeystoreKeyProvider` is provided as the integration point,
  but hardware-backed wrapping is **not** completed in this build — it degrades
  to the passphrase-derived file store. This is a real, documented limitation,
  not a claimed feature.
- **New-device caveat.** Because keys and history live on the device, a new
  device does not silently receive old plaintext: it starts fresh and establishes
  new sessions. There is no server-side escrow of message history.

## 7. Transport and deployment

- Production **must** use HTTPS/WSS with valid certificates. Set
  `MSJ_REQUIRE_TLS=true`; the app rejects plaintext HTTP and emits HSTS.
- Do not disable certificate verification anywhere in the client.
- Recommended: terminate TLS at a reverse proxy (nginx/Caddy) in front of
  uvicorn; see `docs/DEPLOYMENT.md`.

## 8. Deferred features (no security claim made)

- **Groups** — deferred. Shipping group E2EE without correct group key
  distribution and membership-change handling would be insecure.
- **Encrypted attachments** — deferred and disabled. The intended design
  (fresh random content key per file, client-side AES-GCM, ciphertext-only
  upload, key sent inside the E2EE message, no plaintext thumbnails) is
  documented in `docs/ARCHITECTURE.md`, but the feature is off so no plaintext
  file can leak.

## 9. Known limitations summary

- No independent audit.
- Metadata is visible to the server (§2).
- Android hardware-backed key storage not completed (§6).
- In-process rate limiter is per-instance; use a shared store (Redis) for
  multi-instance deployments.
- `xeddsa` is a cffi C extension; packaging for Android may need a custom
  recipe (see `docs/APK_BUILD.md`).
- Server-side retention is time-based (`MSJ_MESSAGE_RETENTION_DAYS`); a
  background purge job should be scheduled in production.

## 10. Incident reporting

If you discover a vulnerability, please report it privately to the maintainers
rather than opening a public issue. Include reproduction steps, affected
versions, and impact. Do not test against systems you do not own.

## 11. Deployment checklist

- [ ] `MSJ_JWT_SECRET` set to a long random value (≥32 bytes), stored as a secret.
- [ ] `MSJ_ENVIRONMENT=production` and `MSJ_REQUIRE_TLS=true`.
- [ ] HTTPS/WSS with a valid certificate; HTTP redirected or rejected.
- [ ] PostgreSQL used (not SQLite); migrations applied (`alembic upgrade head`).
- [ ] Database backups encrypted; understand they contain ciphertext, not plaintext.
- [ ] Rate limits tuned; a shared limiter store configured if running multiple instances.
- [ ] Log aggregation in place; confirm redaction (no tokens/keys/plaintext).
- [ ] Retention purge job scheduled.
- [ ] Admin access least-privilege; no decryption capability exists by design.
