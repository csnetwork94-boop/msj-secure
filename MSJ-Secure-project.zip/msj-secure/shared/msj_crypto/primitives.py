"""Concrete cryptographic primitives plugged into the Double Ratchet.

The ``doubleratchet`` library defines abstract ``KDF``, ``AEAD`` and
``DiffieHellmanRatchet`` interfaces and expects the application to supply
concrete, vetted implementations. We supply the algorithms recommended by the
Signal Double Ratchet specification:

* Key derivation: HKDF-SHA256
* Authenticated encryption: AES-256-GCM (12-byte random nonce, prepended)
* Diffie-Hellman: X25519

All three are provided by the ``cryptography`` library; nothing here is
home-grown.
"""

from __future__ import annotations

import os

from cryptography.exceptions import InvalidTag
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric.x25519 import (
    X25519PrivateKey,
    X25519PublicKey,
)
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
from cryptography.hazmat.primitives.kdf.hkdf import HKDF
from doubleratchet import (
    AEAD,
    KDF,
    AuthenticationFailedException,
    DecryptionFailedException,
    DiffieHellmanRatchet,
    DoubleRatchet,
)
from doubleratchet.types import Header as RatchetHeader

NONCE_SIZE = 12


class HkdfSha256(KDF):
    """HKDF-SHA256 key-derivation function (RFC 5869)."""

    @staticmethod
    async def derive(key: bytes, data: bytes, length: int) -> bytes:
        return HKDF(
            algorithm=hashes.SHA256(),
            length=length,
            salt=None,
            info=data,
        ).derive(key)


class AesGcm(AEAD):
    """AES-256-GCM authenticated encryption with a random 96-bit nonce.

    The nonce is prepended to the ciphertext so the recipient can recover it.
    The GCM tag is appended by ``cryptography`` and verified on decrypt.
    """

    @staticmethod
    async def encrypt(plaintext: bytes, key: bytes, associated_data: bytes) -> bytes:
        nonce = os.urandom(NONCE_SIZE)
        ciphertext = AESGCM(key).encrypt(nonce, plaintext, associated_data)
        return nonce + ciphertext

    @staticmethod
    async def decrypt(ciphertext: bytes, key: bytes, associated_data: bytes) -> bytes:
        if len(ciphertext) < NONCE_SIZE:
            raise DecryptionFailedException("ciphertext too short")
        nonce, body = ciphertext[:NONCE_SIZE], ciphertext[NONCE_SIZE:]
        try:
            return AESGCM(key).decrypt(nonce, body, associated_data)
        except InvalidTag as exc:
            # Honour the Double Ratchet AEAD contract: a failed authentication
            # must surface as AuthenticationFailedException.
            raise AuthenticationFailedException("message authentication failed") from exc


class X25519Ratchet(DiffieHellmanRatchet):
    """X25519 Diffie-Hellman ratchet (Curve25519, RFC 7748)."""

    @staticmethod
    def _generate_priv() -> bytes:
        return X25519PrivateKey.generate().private_bytes(
            encoding=serialization.Encoding.Raw,
            format=serialization.PrivateFormat.Raw,
            encryption_algorithm=serialization.NoEncryption(),
        )

    @staticmethod
    def _derive_pub(priv: bytes) -> bytes:
        return (
            X25519PrivateKey.from_private_bytes(priv)
            .public_key()
            .public_bytes(
                encoding=serialization.Encoding.Raw,
                format=serialization.PublicFormat.Raw,
            )
        )

    @staticmethod
    def _perform_diffie_hellman(own_priv: bytes, other_pub: bytes) -> bytes:
        return X25519PrivateKey.from_private_bytes(own_priv).exchange(X25519PublicKey.from_public_bytes(other_pub))


class MSJDoubleRatchet(DoubleRatchet):
    """Concrete Double Ratchet for MSJ Secure.

    Implements the one application hook the library leaves open: a
    length-prefixed, uniquely reversible encoding of (associated data, header)
    so the AEAD authenticates both without ambiguity.
    """

    @staticmethod
    def _build_associated_data(associated_data: bytes, header: RatchetHeader) -> bytes:
        return (
            len(associated_data).to_bytes(4, "big")
            + associated_data
            + header.ratchet_pub
            + header.previous_sending_chain_length.to_bytes(4, "big")
            + header.sending_chain_length.to_bytes(4, "big")
        )
